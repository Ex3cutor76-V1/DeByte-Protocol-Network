#!/usr/bin/env bash

# Cores
VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
CIANO=$'\033[36m'
MAGENTA=$'\033[35m'
RESET=$'\033[0m'

# Variáveis importantes
comando="$1"
dir="/opt/DPN/scripts"

# Chamando scripts

case "$1" in

-h)
cat << EOF
DPN - DeByte Protocol Network

Sintaxe
dpn <flag> <alvo>

Apoio:

-h     Lista de comandos
-v     Versão da ferramenta

Conectividade:

-c <ip/dominio>   Teste de conectividade

DNS:

-d <dominio>   Teste de DNS

HTTP/HTTPS:

-hs <url>   Teste de HTTPS + Versão TLS
-hp <url>   Teste de HTTP

Interface interna do Host:

-i   Informações de rede do host

EOF
;;

-v)
echo "DPN - DeByte Protocol Network"
echo "Versão: 1.0"
;;

-c)
bash "$dir/ping.sh" "$2"
;;

-d)
bash "$dir/dns.sh" "$2"
;;

-hp)
bash "$dir/http.sh" "$2"
;;

-hs)
bash "$dir/https.sh" "$2"
;;

-i)
bash "$dir/interface.sh"
;;

*)
printf "${VERMELHO}Flag inválida${RESET}\n"
echo "Use: dpn -h"
;;

esac
