#!/usr/bin/env bash

# Cores
VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
CIANO=$'\033[36m'
MAGENTA=$'\033[35m'
RESET=$'\033[0m'

# Teste realizado
printf "${AMARELO}Coletando informações da interface...${RESET}\n"
interface=$(ip route | awk '/^default/ {print $5; exit}')
gateway=$(ip route | awk '/^default/ {print $3; exit}')
ipv4=$(ip -4 addr show "$interface" | awk '/inet / {print $2}')
ipv6=$(ip -6 addr show "$interface" | awk '/inet6 / && !/scope link/ {print $2}')
mac=$(ip link show "$interface" | awk '/link\/ether/ {print $2}')
estado=$(cat /sys/class/net/"$interface"/operstate)
if [ -z "$interface" ]; then
    printf "${VERMELHO}Nenhuma interface encontrada${RESET}\n"
    exit 1
fi
printf "${CIANO}Interface${RESET}\n"
printf "%s\n" "$interface"
printf "${CIANO}Gateway${RESET}\n"
printf "%s\n" "$gateway"
printf "${CIANO}IPv4${RESET}\n"
printf "%s\n" "$ipv4"
printf "${CIANO}IPv6${RESET}\n"
printf "%s\n" "$ipv6"
printf "${CIANO}MAC${RESET}\n"
printf "%s\n" "$mac"
printf "${CIANO}Estado${RESET}\n"
printf "%s\n" "$estado"
