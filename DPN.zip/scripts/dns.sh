#!/usr/bin/env bash

# Cores
VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
CIANO=$'\033[36m'
MAGENTA=$'\033[35m'
RESET=$'\033[0m'

# Variaveis importantes
dominio="$1"

printf "${AMARELO}Gerando informações IPv4 e IPv6...${RESET}\n"
printf "${CIANO}Domínio${RESET}\n"
printf '%s\n' "$dominio"
ipv4=$(getent ahostsv4 "$dominio" | awk 'NR==1 {print $1}')
ipv6=$(getent ahostsv6 "$dominio" | awk 'NR==1 {print $1}')
if [[ -n "$ipv4" ]]; then
printf "${CIANO}IPv4${RESET}\n"
printf '%s\n' "$ipv4"
else
printf "${VERMELHO}IPv4 não encontrado${RESET}\n"
fi

if [[ -n "$ipv6" ]]; then
printf "${CIANO}IPv6${RESET}\n"
printf '%s\n' "$ipv6"
else
printf "${VERMELHO}IPv6 não encontrado${RESET}\n"
fi
