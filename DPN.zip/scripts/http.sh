#!/usr/bin/env bash

# Cores
VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
CIANO=$'\033[36m'
MAGENTA=$'\033[35m'
RESET=$'\033[0m'

# Variáveis importantes
alvo="$1"

# Teste realizado
printf "${AMARELO}Iniciando teste HTTP...${RESET}\n"
codigo=$(curl -s -o /dev/null -w "%{http_code}" "$alvo")
status=$?
if [[ "$status" -ne 0 ]]; then
codigo="$status"
fi
# Catálogo de código HTTP
case "$codigo" in
6)
significado="Não foi possível resolver o host"
;;
7)
significado="Não foi possível conectar ao host"
;;
28)
significado="Tempo limite excedido"
;;
35)
significado="Falha no handshake SSL/TLS"
;;
200)
significado="OK"
;;
301)
significado="Movido permanentemente"
;;
302)
significado="Encontrado"
;;
400)
significado="Requisição inválida"
;;
401)
significado="Não autorizado"
;;
403)
significado="Acesso proibido"
;;
404)
significado="Não encontrado"
;;
500)
significado="Erro interno do servidor"
;;
502)
significado="Gateway inválido"
;;
503)
significado="Serviço indisponível"
;;
204)
significado="Sem conteúdo"
;;
429)
significado="Muitas requisições"
;;
*)
significado="Código não catalogado ainda..."
;;
esac
printf "${CIANO}Alvo:${RESET}\n"
printf "%s\n" "$alvo"
printf "${CIANO}Código:${RESET}\n"
printf "%s\n" "${codigo}"
printf "${CIANO}Significado${RESET}\n"
printf "%s\n" "$significado"
