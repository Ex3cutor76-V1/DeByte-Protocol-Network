#!/usr/bin/env bash

# Esta é a versão IPv6 de scan de vizinhos reconhecidos.

# Variável importante
# Variável de scan
scan_ipv6=$(ip -6 neigh show |
awk '/lladdr/ {
    for (i = 1; i <= NF; i++) {
        if ($i == "dev") iface = $(i+1)
        if ($i == "lladdr") mac = $(i+1)
    }
    print $1, mac, iface
}' |
sort -u)

# Variável total
total=$(printf '%s\n' "$scan_ipv6" |
awk 'NF {count++} END {print count+0}')

# Cores
AMARELO=$'\033[33m'
RESET=$'\033[0m'


# Scan
printf "${AMARELO}Iniciando consulta IPv6...${RESET}\n"
sleep 1
echo "IPv6                         MAC-Adress     Interface"
echo "$scan_ipv6"

# Total de dispositivos
printf '\nEntradas encontrados: %s\n' "$total"
