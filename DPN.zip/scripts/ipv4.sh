#!/usr/bin/env bash

# Essa é a versão IPv4 da consulta de vizinhos

# Variável importante
# Variável de scan
scan_ipv4=$(ip -4 neigh show |
awk '$5 != "" {print $1, $5}' |
sort -Vu)

# Variável total
total=$(printf '%s\n' "$scan_ipv4" | awk 'NF {count++} END {print count+0}')

# Cores
AMARELO=$'\033[33m'
RESET=$'\033[0m'

# Scan
printf "${AMARELO}Iniciando consulta IPv4...${RESET}\n"
sleep 1
echo "IPv4         MAC-Adress"
echo "$scan_ipv4"

# Total de dispositivos
printf '\nEntradas encontrados: %s\n' "$total"
