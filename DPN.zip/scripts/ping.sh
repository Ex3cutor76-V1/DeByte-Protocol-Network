#!/usr/bin/env bash

# Cores

VERMELHO=$'\033[31m'
VERDE=$'\033[32m'
AMARELO=$'\033[33m'
CIANO=$'\033[36m'
MAGENTA=$'\033[35m'
RESET=$'\033[0m'

# Variáveis importantes
alvo="$1"

# Teste realizado
printf "${AMARELO}Realizando testes...${RESET}\n"
resultado=$(ping -c 4 "$alvo")
status=$?

if [[ "$status" -eq 0 ]]; then

# Variável de perda de pacotes
perda=$(printf '%s\n' "$resultado" | awk -F', ' '/packet loss/ {print $3}' | tr -d '%')
# Variável da média de latência
media=$(printf '%s\n' "$resultado" | awk -F'=' '/rtt|round-trip/ {print $2}' | cut -d'/' -f2)

# Clássificação de latência
if awk -v lat="$media" 'BEGIN { exit !(lat < 50) }'; then # Caso seja menor que 50, é verde
COR_LATENCIA="$VERDE"
elif awk -v lat="$media" 'BEGIN { exit !(lat <= 100) }'; then # Caso seja menor ou igual a 100 é amarelo
COR_LATENCIA="$AMARELO"
else # Caso nenhum dos dois é vermelho
COR_LATENCIA="$VERMELHO" 
fi

printf "${VERDE}Teste finalizado com sucesso!${RESET}\n"
printf "${MAGENTA}Resumo do test${RESET}\n"
printf "${CIANO}Perda de pacotes: $perda ${RESET}\n"
printf "${CIANO}Média de latência: ${COR_LATENCIA}${media} ms${RESET}\n"
else
printf "${VERMELHO}Falha no teste de conectividade!${RESET}\n"
fi
